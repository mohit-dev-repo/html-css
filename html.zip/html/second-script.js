// Scope chain - Lexical Scope = Local Memory + L.E. of it's parent (Whenever Execution context gets created L.E. also created)
var y = 20;
function parent() {
    var a = 10;
    child();
    function child() {
        console.log('I got value from window object', y);
        console.log('I got value from my parent function', a);
    }
}

parent();
console.log(y);
// console.log(a);


// Closure - Function bundle with it's Lexical Scope then it forms closure.

function p() {
    let a = 5;
    function y() {
        console.log(a);
    }
    return y;
}

var z = p();

console.log(z);

z();

let multiply = function(x) {
    var z = 5;
    return function(y) {
        console.log(x*y*z);
    }
}

let multiplyBy2 = multiply(2);
console.log(multiplyBy2);
multiplyBy2(5); // 50

// Interview Question
    // Problem
    // for(var i=1; i<=5; i++) {
    //     setTimeout(function() {
    //         console.log(i);
    //     }, i* 1000);
    // }

    //  Solution
    // for(let i=1; i<=5; i++) {
    //     setTimeout(function() {
    //         console.log(i);
    //     }, i* 1000);
    // }

// // call, apply, bind

let obj1 = {
    firstName: 'Anamika',
    lastName: 'Jain',
    fullName: function(homeTown, state, country) {
        console.log(`${this.firstName} ${this.lastName} ${homeTown} ${state} ${country}`);
    }
}

let obj2 = {
    firstName: 'Anmol',
    lastName: 'Gupta'
}
    // funtion borrowing
    obj1.fullName.call(obj2, 'Bhopal', 'MP', 'India');
    obj1.fullName.apply(obj2, ['Bhopal', 'MP', 'India']);

    let myBindingMethod = obj1.fullName.bind(obj2, 'Bhopal', 'MP', 'India');
    console.log(myBindingMethod());

// // Prototypical Inheritance

obj2.__proto__ = obj1;
obj2.__proto__.firstName = 'Anjali';
console.log(obj1.firstName);
console.log(obj2.__proto__.firstName);

function Student(first, last) {
    this.firstName = first;
    this.lastName = last;
}

Student.prototype.homeTown = 'Bhopal';

Student.prototype.customMethod = function() {
    console.log('custom one');
};

const anmol = new Student('Anmol', 'Gupta');
console.log(anmol.__proto__.homeTown);

// // String Method

let myCustomString = 'ABCDEFG HIJKLMNOPQRS TuvWXYZ    ';

console.log('myCustomString.length', myCustomString.length);
console.log('myCustomString.slice(2, 5)', myCustomString.slice(2, 5));
console.log('myCustomString.split(" ")', myCustomString.split(" "));
console.log('myCustomString.substr(0, 5)', myCustomString.substr(0, 5));
console.log('myCustomString.substring(2, 5)', myCustomString.substring(2, 5));
console.log('myCustomString.replace("ABC", "XYZ")', myCustomString.replace("ABC", "XYZ"));
console.log('myCustomString.toLowerCase()', myCustomString.toLowerCase());
console.log('myCustomString.toUpperCase()', myCustomString.toUpperCase());
console.log('myCustomString.trim()', myCustomString.trim());
console.log('myCustomString.concat("1234")', myCustomString.concat('12345'));
console.log('myCustomString.charAt(0)', myCustomString.charAt(0));
console.log('myCustomString.indexOf(A)', myCustomString.indexOf('C'));


// let arr = ['abcefg', 'pqrst', 'xyz'];

// console.log(arr.toString().toUpperCase().toLowerCase());

// arr.forEach(e => {
//     if(e.length > 4) {
//         console.log(e);
//     }
// })


// Palindrom - If the string and it's reverse is same then the string is palindrom.

// let str1 = "abba";

// const isPalindrom = function(str) {
//     // console.log(str.split(''));
//     // let arrStr = str.split('');
//     // arrStr = arrStr.reverse();
//     // console.log(arrStr);
//     // let outcome = arrStr.join('');
//     // console.log(outcome);
//     // return str === str.split('').reverse().join(''); 
//     for (let i = 0; i< str.length/2; i++) {
//         if(str.charAt(i) !== str.charAt(str.length-i-1)) {
//             return false;
//         }
//         return true;
//     }
// }

// const result = isPalindrom(str1);
// console.log(result);


// // Array Methods

// let myArr1 = ['Jai', 'Ajay', 'Vijay', 'Sanjay', 'Dhananjay'];
// let myArr2 = ['Pinky', 'Dinky', 'Rinky'];

// let numArr = [3, 6, 2, 1, 8, 7];
// console.log('length', myArr1.length);
// console.log('sort', numArr.sort());
// console.log('sort', myArr1.sort());
// console.log('push', myArr1.push('Vinay'));
// console.log('pop', myArr1.pop());
// console.log('concat', myArr1.concat(myArr2));
// console.log('toString', myArr1.toString());
// console.log('shift', myArr1.shift());
// console.log('array', myArr1);
// console.log('unshift', myArr1.unshift('Vinay'));
// console.log('array', myArr1);
// console.log('splice', myArr1.splice(2, 0, 'Sujay')); // Add at postion 2
// console.log('array', myArr1);
// console.log('splice', myArr1.splice(2, 2)); // Remove at postion 2
// console.log('array', myArr1);
// const slicedArr = myArr1.slice(1);
// console.log('slicedArr', slicedArr);
// console.log('myArr1', myArr1);
// const myEle = myArr1.indexOf('Dhananjay');
// console.log(myEle);

// const str = 'abcdefg';
// const subStr = 'def';

// console.log(str.includes(subStr));


// console.log(myArr2.includes('Rinkys'));

let arrToSort = ['I', 'am', 'programming', 'in', 'java'];

const sort = function(arr) {
    // Insertion Sort
    for (let i = 1; i<arr.length; i++) {
        var temp = arr[i];
        var j = i-1;
        while(j>=0 && temp.length < arr[j].length) {
            arr[j+1] = arr[j];
            j--;
        }
        arr[j+1] = temp;
    }
    return arrToSort;
    // Selection Sort
    // let n = arr.length;
    // for(let i=0; i < n; i++) {
    //     let min = i;
    //     for(j=i+1; j<n; j++) {
    //         if(arr[j].length < arr[min].length) {
    //             min = j;
    //         }
    //     }
    //     if(min != i) {
    //         let temp = arr[i];
    //         arr[i] = arr[min];
    //         arr[min]= temp;
    //     }
    // } 
    // return arr;
}

sort(arrToSort); 
console.log('sort', arrToSort);


let string1 = "Army";
let string2 = "Mary";

const isAnagram = function(str1, str2) {
    if(str1.length === str2.length) {
        str1 = str1.toLowerCase().split("").sort().join('');
        str2 = str2.toLowerCase().split("").sort().join('');      
    }
    return str1 === str2;
} 

const res = isAnagram(string1, string2);
console.log(res);

// Array Iterators

let arr = [5, 20, 25, 30, 35, 10, 15, 40, 45, 50];

// for(let i=arr.length; i>0; i--) {
//     if(i%2 === 0) {
//         arr.splice(i, 1);
//     }
//     // console.log(index);
//     // if(index == i) {
//     //     arr.splice(index, 1);
//     // }
//     // arr[i];   
// }


// //  foreach should not be used for multiple deletion of element.
// arr.forEach((el, index) => {
//     // if(index%2 === 0) {
//     //     arr.splice(index, 1);
//     // }
//      console.log(`${index} : ${el}`);
// })
// console.log(arr);

// // processing current array and return data in new array
// let newArr = arr.map(function(value, index) {
//     return {key: index, value: value + 2};
// });
// console.log(arr);
// console.log(newArr);

// // filter out elements on a condition into a new array
// let filteredArr = arr.filter(el => {
//     return el > 32;
// })

// console.log(filteredArr);

// // reduce to as single value from an array

// function reduceToSum(total, value, index) {
//     return total + value;
// }
// let sum = arr.reduce(reduceToSum);

// console.log(sum);

// // every returns a boolean if all elements of array satisfy a condition
// let everyRes = arr.every(el => {
//     return el > 2;
// })

// console.log(everyRes);

// // some returns a boolean if any element of array satisfy a condition
// let someRes = arr.some(el => {
//     return el > 25;
// })

// console.log(someRes);

// // find returns the element which satisfy a condition
// let findEl = arr.find(el => {
//     return el >= 25;
// })

// console.log(findEl);

// // findIndex returns the index of element which satisfy a condition
// let index = arr.findIndex(el => {
//     return el >= 25;
// })

// console.log(index);

// // includes return a boolean if an element is there in the array
// // works for string also array
// let check25 = arr.includes(25);
// console.log(check25);

// Array.from returns an array and it can work on any iterable data(object/string/array)
const fromArr = Array.from('ABC1232435DEFG');
console.log(fromArr);

//  Object Iteration
const object = { a: 1, b: 2, c: 3 };

for (const i in object) {
  console.log(`${i}: ${object[i]}`);
}

const object1 = {
    a: 'somestring',
    b: 42
  };
  
  for (const [key, value] of Object.entries(object1)) {
    console.log(`${key}: ${value}`);
  }


// Array destructring

let [, , third, , fifth] = [1,2,3,4,5];
console.log(fifth);

const hero = {
    name: 'Batman',
    realName: 'Bruce Wayne'
};
  
const { realName, name } = hero;
console.log(realName);

//  Rest Parameters
function sum(...args) {
    let sum = '';
    for (let arg of args) {
        sum += arg; 
    }
    return sum;
}

let x = sum('fadad', 10, 'adafafaf');
console.log(x);

// Set - a collection of unique set of elements

const letters = new Set(['a', 'b', 'a']);
console.log(letters);
console.log(typeof letters);

let numArray = [1,2,3,6,7,5,3,1,2,8];

// let uniqueArr = [];
// uniqueArr = numArray.filter((el, index) => {
//     return !uniqueArr.includes(el);
// })

// let uniqueArr = [];
// numArray.forEach(el => {
//     if(!uniqueArr.includes(el)) {
//         uniqueArr.push(el);
//     }
// })
// console.log(uniqueArr);

// var uniqueArr = [];

// for(var i = 0; i< numArray.length; i++) {
//     if(uniqueArr.indexOf(numArray[i]) == -1) {
//         uniqueArr.push(numArray[i]);
//     }
// }

// console.log(uniqueArr);

//  for of 

let text = "";
let str = "ABCDEFGHIJ";
let arrayOf = [1, 2, 3, 4, 6, 8];
for(let x of arrayOf) {
    console.log(x);
}

let flatMapArr = [1, 2, [3, 4], [5, 6]];
const resFM = flatMapArr.flatMap(x => x*3);
console.log(resFM);