// JS is a synchronous single threaded language.

// Concept
console.log(this);
console.log(window);
console.log(this === window);

// Hoisting

    console.log(a);
    // console.log(b);
    // console.log(c);
    console.log(d());
    console.log(functionVar);


    var a = 10;
    let b = 20;
    const c = 30;

    // function statement / declaration
    function d() {
        console.log('Hey');
    }

    // function expression
    var functionVar = function e() {
        console.log('Hey');
    }

    console.log(a);
    console.log(b);
    console.log(c);
    console.log(d);

// JS Working
    var n = 10;

    function square(num) {
        var result = num * num;
        console.log('will be called', result);
        return result;
    }

// Functions details
    // Functions are first class citizens - statement, expression (variable), anonymous, declare function inside function, pass function as a parameter
    function functionAsParam(square) {
        console.log('my callback function', square);
    }

    functionAsParam(square);

    function noFatArrowFunction() {

    }

    var fatArrowFunction = () => {
        
    }

var sqaure2 = square(2);
var square10 = square(n);

function printSquare(num) {
    return num*num;
}

function printCube(num) {
    return num*num*num;
}

function squareCube(num) {
    for(let i=1; i<=num; i++) {

        var b = 30;
        if(i%2 === 0) {
          let mySqure =  printSquare(i);
          console.log(mySqure);
        } else {
            let myCube = printCube(i);
            console.log(myCube);
        }
        console.log('inside b =>', b);
    }    
    console.log('outside b =>', b);
    // let i=1;
    // while(i<=num) {
    //     if(i%2 === 0) {
    //         let mySqure =  printSquare(i);
    //         console.log(mySqure);
    //     } else {
    //         let myCube = printCube(i);
    //         console.log(myCube);
    //     }
    //     i++;
    // }
}

// squareCube(10);

function name() {
    // functional scope
}

function name2() {
    // functional scope
    var a = 10;
    let c = 30;
    for(let i=0; i<=10; i++) {
        // block scope
        let z = 50;
        var b = 20;
        console.log(i);
    }
    console.log(a);
    console.log(b);
    console.log(c);
    console.log(z);
}

name2();

// function outer() {
//     var a = 10;
//     let b = 5;
//     function inner() {
//         let b = 15;
//         var a = 20;
//         console.log('inner', a);
//         console.log('inner', b);
//     }
//     inner();
//     console.log('outer', a);
//     console.log('outer', b);
// }

// outer();